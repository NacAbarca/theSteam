<?php
/**
 * Widget Dishes File Doc Comment
 *
 * @category File
 * @package  TheSteam
 * @author   WDI
 * @license  GPLv2 or later
 * @license  URI http://www.gnu.org/licenses/gpl-2.0.html
 * @link     www.webdotinc.com
 * Text Domain: thesteam
 **/

if ( ! class_exists( 'TheSteam_Dishes_Widget' ) ) {
	/**
	 * TheSteam_Dishes_Widget Class Doc Comment
	 *
	 * @category Class
	 * @package  TheSteam
	 * @author   WDI
	 * @license  GPLv2 or later
	 * @link     www.webdotinc.com
	 * Text Domain: thesteam
	 **/
	class TheSteam_Dishes_Widget extends WP_Widget
	{
		/**
		 * Constructor
		 */
		function __construct() {

			parent::__construct(
				'TheSteam_Dishes_Widget',
				esc_html__( 'The Steam Dishes Widget', 'thesteam' ),
				array( 'description' => esc_html__( 'Dishes Widget from The Steam Theme', 'thesteam' ) )
			);
		}

		/**
		 * Calls function that renders widget
		 *
		 * @param array $args Arguments.
		 * @param array $instance Current Instance.
		 */
		public function widget( $args, $instance ) {

			the_steam_display_dishes_widget( $args, $instance );
		}

		/**
		 * Admin form
		 *
		 * @param array $instance Current instance.
		 * @return string Empty string.
		 */
		public function form( $instance ) {

			if ( array_key_exists( 'title', $instance ) && isset( $instance['title'] ) ) {
				$title = $instance['title'];
			} else {
				$title = esc_html__( 'FEATURED DISHES', 'thesteam' );
			}
			// Widget admin form.
			?>
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'thesteam' ); ?></label>
				<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"
					   name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text"
					   value="<?php echo esc_attr( $title ); ?>"/>
			</p>
			<?php
			return '';
		}

		/**
		 * Updates widget replacing the old instances with a new one
		 *
		 * @param array $new_instance New instance.
		 * @param array $old_instance Old instance.
		 *
		 * @return array New instance
		 */
		public function update( $new_instance, $old_instance ) {

			$instance = array();
			$instance['title'] = ( array_key_exists( 'title', $new_instance ) && ! empty( $new_instance['title'] )) ? strip_tags( $new_instance['title'] ) : '';

			return $instance;
		}
	}
}

if ( ! function_exists( 'the_steam_load_widget_dishes' ) ) {
	/**
	 * Registers and loads the widget
	 */
	function the_steam_load_widget_dishes() {

		register_widget( 'TheSteam_Dishes_Widget' );
	}

	add_action( 'widgets_init', 'the_steam_load_widget_dishes' );
}

if ( ! function_exists( 'the_steam_request_dish_sharecount_update' ) ) {
	/**
	 * Prints out javascript needed to update each item's share count
	 *
	 * @param int    $id Post id.
	 * @param string $permalink Post permalink.
	 */
	function the_steam_request_dish_sharecount_update( $id, $permalink ) {
		?>
		<script type="text/javascript">requestSharecountUpdate("<?php echo esc_js( $id );?>","<?php echo esc_url( $permalink ); ?>");</script>;
	<?php
	}
}


if ( ! function_exists( 'the_steam_display_dishes_widget' ) ) {
	/**
	 * Renders the widget
	 *
	 * @param array $args Widget args like before and after widget.
	 * @param array $instance Current instance.
	 */
	function the_steam_display_dishes_widget( $args, $instance ) {

		?>
		<?php echo wp_kses( $args['before_widget'], the_steam_get_valid_theme_kses() ); ?>

		<p class="most-read">
			<?php
			$title = null;
			$done_first_el = false;

			if ( array_key_exists( 'title', $instance ) && isset( $instance['title'] ) ) {
				$title = apply_filters( 'widget_title', $instance['title'] );
			}

			if ( ! empty( $title ) ) { echo esc_html( $title ); } ?>
		</p>

		<div class="post-container">
			<div class="dish-widget-container">
				<hr class="top-line">
				<ul class="post-selector side-nav">
					<?php
					$rand_dish_query_args = array(
						'post_type' => 'dish',
						'posts_per_page' => '4',
						'orderby' => 'rand',
						'ignore_sticky_posts' => 1,
					);
					$result = new WP_Query( $rand_dish_query_args ); ?>
					<?php if ( $result->have_posts() ) : ?>

						<?php while ( $result->have_posts() ) : $result->the_post(); ?>
							<?php $featured_img = wp_get_attachment_url( get_post_thumbnail_id( $result->post->ID ) ) ? wp_get_attachment_url( get_post_thumbnail_id( $result->post->ID ) ) : '#'; ?>
							<li class="post-selector-item clickable" onClick="location.href='<?php echo esc_url( get_the_permalink() ); ?>'">
								<div class="most-read-blog-post">
								<?php if ( 5 < strlen( $featured_img ) ) : ?>
									<img alt="<?php echo esc_attr( substr( get_the_title(), 0, 30 ) ); ?>"
										 src="<?php echo esc_url( $featured_img ); ?>"
										 class="most-read-blog-post">
								<?php endif; ?>
								</div>
								<div class="side-thumbs-info-widget <?php if ( ! $done_first_el ) { echo esc_attr( 'first-row-widget' );
									$done_first_el = true; } ?>">
									<div class="align-items-side">
										<table class="tg-side" title="<?php echo esc_html( $result->post->post_title ); ?>">
											<tr>
												<th class="tg-t7cm-side">
													<div class="first-line-side"><?php echo esc_html( the_steam_get_elipsis( $result->post->post_title, 23 ) ); ?></div>
												</th>
											</tr>
											<tr>
												<td class="tg-t7cm-side">
													<hr class="third-line-side">
												</td>
											</tr>
											<tr>
												<td class="tg-t7cm-side">
													<div class="forth-line-side">
														<p class="icon-links-side">
															<a href="#">
																<i class="fa fa-eye"></i>
																<span class="icon-heart-side"><?php echo esc_html( the_steam_get_blogpost_views( $result->post->ID ) ); ?></span>
															</a>
															<a href="#">
																<i class="fa fa-envelope-o"></i>
																<span
																	class="icon-heart-side"><?php echo esc_html( get_comments_number( $result->post->ID ) ); ?></span>
															</a>
															<a href="#">
																<i class="fa fa-share-alt"></i>
															<span class="icon-heart-side"
																  id="share-icon-feat-<?php echo esc_attr( $result->post->ID ); ?>">
																	<?php the_steam_request_dish_sharecount_update( 'share-icon-feat-'.$result->post->ID, esc_url( get_the_permalink() ) ); ?>
															</span>
															</a>
														</p>
													</div>
												</td>
											</tr>
										</table>
									</div>
								</div>
							</li>
						<?php endwhile; ?>
					<?php endif; ?>
				</ul>
			</div>
		</div>
		<?php wp_reset_postdata(); ?>
		<?php echo wp_kses( $args['after_widget'], the_steam_get_valid_theme_kses() ); ?>
		<?php
	}
}
?>
