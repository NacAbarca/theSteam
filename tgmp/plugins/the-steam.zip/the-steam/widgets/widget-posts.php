<?php
/**
 * Widget Posts File Doc Comment
 *
 * @category File
 * @package  TheSteam
 * @author   WDI
 * @license  GPLv2 or later
 * @link     www.webdotinc.com
 * Text Domain: thesteam
 **/

if ( ! class_exists( 'TheSteam_MostRead_Widget' ) ) {
	/**
	 * TheSteam_MostRead_Widget Class Doc Comment
	 *
	 * @category Class
	 * @package  TheSteam
	 * @author   WDI
	 * @license  GPLv2 or later
	 * @link     www.webdotinc.com
	 * Text Domain: thesteam
	 **/
	class TheSteam_MostRead_Widget extends WP_Widget
	{
		/**
		 * Constructor
		 */
		function __construct() {

			parent::__construct(
				'TheSteam_MostRead_Widget',
				esc_html__( 'The Steam Most Read Posts Widget', 'thesteam' ),
				array( 'description' => esc_html__( 'Most Read Posts Widget from The Steam Theme', 'thesteam' ) )
			);
		}

		/**
		 * Calls function to render widget
		 *
		 * @param array $args Widget arguments, like before widget, etc.
		 * @param array $instance Current widget instance.
		 */
		public function widget( $args, $instance ) {

			the_steam_display_most_read_widget( $args, $instance );
		}

		/**
		 * Renders admin form for the widget
		 *
		 * @param array $instance Current instance.
		 * @return string Empty string.
		 */
		public function form( $instance ) {

			if ( array_key_exists( 'title', $instance ) && isset( $instance['title'] ) ) {
				$title = $instance['title'];
			} else {
				$title = esc_html__( 'MOST READ', 'thesteam' );
			}
			// Widget admin form.
			?>
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'thesteam' ); ?></label>
				<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"
					   name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text"
					   value="<?php echo esc_attr( $title ); ?>"/>
			</p>
			<?php
			return '';
		}

		/**
		 * Updates widget
		 *
		 * @param array $new_instance Old instance.
		 * @param array $old_instance New instance.
		 *
		 * @return array New instance
		 */
		public function update( $new_instance, $old_instance ) {

			$instance = array();
			$instance['title'] = ( array_key_exists( 'title', $new_instance ) && ! empty( $new_instance['title'] )) ? strip_tags( $new_instance['title'] ) : '';
			return $instance;
		}
	}
}


if ( ! function_exists( 'the_steam_request_sharecount_update' ) ) {
	/**
	 * Prints out javascript needed to update each item's share count
	 *
	 * @param int    $id Post id.
	 * @param string $permalink Post permalink.
	 */
	function the_steam_request_sharecount_update( $id, $permalink ) {
	?>
		<script type="text/javascript">requestSharecountUpdate("<?php echo esc_js( $id );?>","<?php echo esc_url( $permalink ); ?>");</script>;
	<?php
	}
}

if ( ! function_exists( 'the_steam_load_widget_most_read' ) ) {
	/**
	 * Registers widget.
	 */
	function the_steam_load_widget_most_read() {

		register_widget( 'TheSteam_MostRead_Widget' );
	}
}
add_action( 'widgets_init', 'the_steam_load_widget_most_read' );


if ( ! function_exists( 'the_steam_display_most_read_widget' ) ) {
	/**
	 * Renders widget
	 *
	 * @param array $args Widget args.
	 * @param array $instance Current widget instance.
	 */
	function the_steam_display_most_read_widget( $args, $instance ) {
		?>
		<?php echo wp_kses( $args['before_widget'], the_steam_get_valid_theme_kses() ); ?>
		<p class="most-read">
			<?php
			$title = null;
			$done_first_el = false;

			if ( array_key_exists( 'title', $instance ) && isset( $instance['title'] ) ) {
				$title = apply_filters( 'widget_title', $instance['title'] );
			}

			if ( ! empty( $title ) ) {
				echo esc_html( $title );
			} ?>
		</p>

		<div class="post-types-selector">
			<ul class="post-types-align">
				<li class="post-selector-button"><a id="month-tab-selector" class="post-topitem no-load"><?php esc_html_e( 'MONTH', 'thesteam' ); ?></a></li>
				<li class="post-selector-button vertical-line-side"><p class="post-topitem">|</p></li>
				<li class="post-selector-button"><a id="year-tab-selector" class="post-topitem no-load"><?php esc_html_e( 'YEAR', 'thesteam' ); ?></a></li>
			</ul>
		</div>
		<div class="post-container">
			<!-- 4 per month -->
			<div class="month">
				<hr class="top-line">
				<ul class="post-selector side-nav">
					<?php
					$current_month = date( 'm' );

					$month_query_args = array(
						'post_type' => 'post',
						'posts_per_page' => '4',
						'monthnum' => $current_month,
						'meta_key' => 'the_steam_blogpost_views_count',
						'orderby' => 'meta_value_num',
						'order' => 'DESC',
						'ignore_sticky_posts' => 1,
					);

					$month_res = new WP_Query( $month_query_args );
				/* Backup query */
		if ( $month_res->found_posts < 4 ) {
			wp_reset_postdata();
			$month_query_args = array(
			'post_type' => 'post',
			'posts_per_page' => '4',
			'order' => 'DESC',
			'ignore_sticky_posts' => 1,
			);
			$month_res = new WP_Query( $month_query_args );
		}
		if ( $month_res->have_posts() ) : ?>
						<?php while ( $month_res->have_posts() ) : $month_res->the_post(); ?>
						<?php $featured_img = wp_get_attachment_url( get_post_thumbnail_id( $month_res->post->ID ) ) ? wp_get_attachment_url( get_post_thumbnail_id( $month_res->post->ID ) ) : '#'; ?>
							<li class="post-selector-item clickable"
								onClick="location.href='<?php the_permalink(); ?>'">
								<div class="most-read-blog-post">
								<?php if ( 5 < strlen( $featured_img ) ) : ?>
									<img alt="<?php echo esc_attr( get_the_title(), 30 ); ?>"
										 src="<?php echo esc_url( $featured_img ); ?>"
										 class="most-read-blog-post">
								<?php endif; ?>
								</div>
								<div class="side-thumbs-info-widget <?php if ( ! $done_first_el ) { echo esc_attr( 'first-row-widget' );
									$done_first_el = true; } ?>">
									<div class="align-items-side">
										<table class="tg-side" title="<?php echo esc_html( $month_res->post->post_title ); ?>">
											<tr>
												<th class="tg-t7cm-side">
													<div
														class="first-line-side"><?php echo esc_html( the_steam_get_elipsis( $month_res->post->post_title, 23 ) ); ?></div>
												</th>
											</tr>
											<tr>
												<td class="tg-t7cm-side">
													<hr class="third-line-side">
												</td>
											</tr>
											<tr>
												<td class="tg-t7cm-side">
													<div class="forth-line-side">
														<p class="icon-links-side"><a href="#"><i
																	class="fa fa-eye"></i><span
																	class="icon-heart-side"><?php echo esc_html( the_steam_get_blogpost_views( $month_res->post->ID ) ); ?></span></a><a
																href="#"><i class="fa fa-envelope-o"></i><span
																	class="icon-heart-side"><?php echo esc_html( get_comments_number( $month_res->post->ID ) ); ?></span></a><a
																href="#"><i
																	class="fa fa-share-alt"></i><span
																	class="icon-heart-side"
																	id="share-icon-<?php echo esc_html( $month_res->post->ID ); ?>">
																		<?php the_steam_request_sharecount_update( 'share-icon-'.$month_res->post->ID, get_the_permalink() ); ?>
																	</span></a>
														</p>
													</div>
												</td>
											</tr>
										</table>
									</div>
								</div>
							</li>
						<?php endwhile; ?>
					<?php endif; ?>

				</ul>
			</div>
			<!-- si alte 4 pe year -->
			<div class="year">
				<hr class="top-line">
				<ul class="post-selector side-nav">
					<?php
					$current_year = date( 'Y' );

					$year_query_args = array(
						'post_type' => 'post',
						'posts_per_page' => '4',
						'yearnum' => $current_year,
						'meta_key' => 'the_steam_blogpost_views_count',
						'orderby' => 'meta_value_num',
						'order' => 'DESC',
						'ignore_sticky_posts' => 1,
					);

					$year_res = new WP_Query( $year_query_args );

		if ( $year_res->found_posts < 4 ) {
			$year_query_args = array(
			'post_type' => 'post',
			'posts_per_page' => '4',
			'order' => 'DESC',
			'ignore_sticky_posts' => 1,
			);
			$year_res = new WP_Query( $year_query_args );
		}
					?>
					<?php if ( $year_res->have_posts() ) : ?>
						<?php while ( $year_res->have_posts() ) : $year_res->the_post(); ?>
							<?php $featured_img = wp_get_attachment_url( get_post_thumbnail_id( $year_res->post->ID ) ) ? wp_get_attachment_url( get_post_thumbnail_id( $year_res->post->ID ) ) : '#'; ?>
							<li class="post-selector-item clickable"
								onClick="location.href='<?php the_permalink(); ?>'">
								<div class="most-read-blog-post">
								<?php if ( 5 < strlen( $featured_img ) ) : ?>
									<img alt="<?php echo esc_html( the_steam_get_elipsis( $year_res->post->post_title, 23 ) ); ?>"
										 src="<?php echo esc_url( $featured_img ); ?>"
										 class="most-read-blog-post">
								<?php endif; ?>
								</div>
								<div class="side-thumbs-info-widget">
									<div class="align-items-side">
										<table class="tg-side" title="<?php echo esc_html( $year_res->post->post_title ); ?>">
											<tr>
												<th class="tg-t7cm-side">
													<div
														class="first-line-side"><?php echo esc_html( the_steam_get_elipsis( $year_res->post->post_title, 23 ) ); ?></div>
												</th>
											</tr>
											<tr>
												<td class="tg-t7cm-side">
													<hr class="third-line-side">
												</td>
											</tr>
											<tr>
												<td class="tg-t7cm-side">
													<div class="forth-line-side">
														<p class="icon-links-side">
															<a href="#">
																<i class="fa fa-eye"></i>
																<span
																	class="icon-heart-side"><?php echo esc_html( the_steam_get_blogpost_views( $year_res->post->ID ) ); ?></span>
															</a>
															<a href="#">
																<i class="fa fa-envelope-o"></i>
																<span
																	class="icon-heart-side"><?php echo esc_html( get_comments_number( $year_res->post->ID ) ); ?></span>
															</a>
															<a href="#">
																<i class="fa fa-share-alt"></i>
														<span class="icon-heart-side"
															  id="share-icon-year-<?php echo esc_html( $year_res->post->ID ); ?>">
																		<?php the_steam_request_sharecount_update( 'share-icon-year-'.$year_res->post->ID, get_the_permalink() ); ?>
														</span>
															</a>
														</p>
													</div>
												</td>
											</tr>
										</table>
									</div>
								</div>
							</li>
						<?php endwhile; ?>
					<?php endif; ?>
				</ul>
			</div>
		</div>
		<?php wp_reset_postdata(); ?>
		<?php echo wp_kses( $args['after_widget'], the_steam_get_valid_theme_kses() ); ?>
		<?php
	}
}
?>
