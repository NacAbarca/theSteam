This theme and the accompanying plugin comes only with a couple languages for now. More languages are to be integrated in time. 

Also, please note that all .po files are available in this directory, if you wish to do a translation for another language than the ones currently available, you can use POEdit to update current translation files or add new ones based on these.

Thank you for choosing The Steam theme!