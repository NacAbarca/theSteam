<?php
/**
 * Instagram Exception File Doc Comment
 *
 * This file contains the Instagram Exception needed for the Instagram plugin
 *
 * @category File
 * @package  TheSteam
 * @author   WDI
 * @license  GPLv2 or later
 * @link     www.webdotinc.com
 **/

namespace MetzWeb\Instagram;

/**
 * InstagramException Class Doc Comment
 *
 * Class extends basic exception
 *
 * @category Class
 * @package  TheSteam
 * @author   WDI
 * @license  GPLv2 or later
 * @link     www.webdotinc.com
 * Text Domain: thesteam
 **/
class InstagramException extends \Exception
{
}
