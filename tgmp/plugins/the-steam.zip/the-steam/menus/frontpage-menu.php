<?php
/**
 * Frontpage Menu Doc Comment
 *
 * This file registers the frontpage menu
 *
 * @category File
 * @package  TheSteam
 * @author   WDI
 * @license  GPLv2 or later
 * @license  URI http://www.gnu.org/licenses/gpl-2.0.html
 * @link     www.webdotinc.com
 * Text Domain: thesteam
 **/

?>
<?php
add_action( 'init', 'register_frontpage_menu' );
	/**
	 * Registers frontpage navigation menu with WordPress
	 */
function register_frontpage_menu() {
	register_nav_menu( 'frontpage-menu', esc_html__( 'Front Page Menu', 'thesteam' ) );
}

