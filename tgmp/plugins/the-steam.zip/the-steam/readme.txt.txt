The-Steam plugin is provided along with the "The Steam" theme in order to provide functionality needed by the theme. The theme will not function without having this plugin installed since specific functions that are the heart of the theme cannot be used elsewhere than a plugin. However, the use of this plugin should not interfere with any other theme that you have installed.

For more information regarding this plugin or The Steam theme, please consul the documentation file.

Thank you,
webdotinc team