<?php
/**
 * Plugin Doc Comment
 *
 * This file contains TheSteam Plugin
 *
 * @category File
 * @package  TheSteam
 * @author   WDI
 * @license  GPLv2 or later
 * @license  URI: http://www.gnu.org/licenses/gpl-2.0.html
 * @link     www.webdotinc.com
 * Text Domain: thesteam
 **/

/**
 * This plugin accompanies The Steam theme
 *
 * It provides helpers and functionality needed by the base theme
 *
 * Plugin Name: The Steam
 * Plugin URI: http://www.webdotinc.net/thesteam
 * Description: Plugin that accompanies The Steam theme
 * Version: 1.8
 * Author: WDI
 * Author URI: http://www.webdotinc.com
 * Text Domain: thesteam
 * License: GPLv2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 */

require_once plugin_dir_path( __FILE__ ) . '/widgets/widget-posts.php';
require_once plugin_dir_path( __FILE__ ) . '/widgets/widget-dishes.php';
require_once plugin_dir_path( __FILE__ ) . '/../../../wp-admin/includes/image.php';
require_once plugin_dir_path( __FILE__ ) . '/instagram/Instagram.php';
use MetzWeb\Instagram\Instagram as Instagram;



if ( ! function_exists( 'the_steam_get_instagram_feed_items' ) ) {
	/**
	 * Retrieves an array of image URLs from Instagra
	 *
	 * @param string $key Token API Key used to authenticate to Instagram servers.
	 *
	 * @return array|null An array of image URLs if successful, null on failure
	 */
	function the_steam_get_instagram_feed_items( $key ) {
		if ( ! isset( $key ) || '' === $key ) {
			return null; }

		$instagram = new Instagram(array(
			/* can't be left blank as API requires theme at construction, although they are not used */
			'apiKey' => 'X',
			'apiSecret' => 'X',
			'apiCallback' => 'X',
		));
		$instagram->setAccessToken( $key );
		$result = $instagram->getUserMedia();
		$ret = array();
		$index = 0;

		if ( ! isset( $result ) || ! isset( $result->data ) ) {
			return null;
		}

		foreach ( $result->data as $media ) {
			$image_url = '';

			if ( 'video' !== $media->type  ) {
				// Image.
				$index++;
				$image_url = $media->images->standard_resolution->url;
			}

			$ret[ $index ] = $image_url;
		}

		return $ret;
	}
}

add_action( 'template_redirect', 'the_steam_last_modified_header' );
function the_steam_last_modified_header( $headers ) {
	/**
	 * Google SEO - 304 If-modified-since headers
	 *
	 * @param string $headers HTTP Headers
	 */
	if ( 'yes' === the_steam_get_option( 'option_enable_last_modified_headers' ) && is_singular() ) {
		$post_id = get_queried_object_id();

		if ( $post_id ) {
			header( 'Last-Modified: ' . get_the_modified_time( 'D, d M Y H:i:s', $post_id ) );
		}
	}

}

if ( ! function_exists( 'the_steam_create_demo_categories' ) ) {
	/**
	 * Function run at plugin intialization that creates demo categories
	 */
	function the_steam_create_demo_categories() {
		if ( ! current_user_can( 'manage_categories' ) ) {
			die( esc_html__( 'Insufficient permissions!', 'thesteam' ) );
		}

		$demo_categories = simplexml_load_file( get_template_directory() . '/inc/demos/export-categories.xml' );

		if ( false === $demo_categories ) {
			return;
		}

		foreach ( $demo_categories as $demo_category ) {

			$args = array(
				'description' => esc_html( (string) $demo_category->description ),
				'slug' => esc_html( (string) $demo_category->slug ),
				'parent' => 0,
			);

			$term = wp_insert_term( (string) $demo_category->name, 'category', $args );

			if ( is_wp_error( $term ) ) {
				continue;
			}

			$category_meta = get_option( 'category_term_' . $term['term_id'] );
			$category_meta['category_id'] = esc_html( (string) $demo_category->featured_image );

			update_option( 'category_term_' . $term['term_id'], $category_meta );
		}

	}
}

if ( ! function_exists( 'the_steam_create_demo_posts' ) ) {
	/**
	 * Function run at plugin intialization that creates demo posts
	 */
	function the_steam_create_demo_posts() {
		if ( ! current_user_can( 'manage_categories' ) ) {
			die( esc_html__( 'Insufficient permissions!', 'thesteam' ) );
		}

		$demo_posts = simplexml_load_file( get_template_directory() . '/inc/demos/export-posts.xml', null, LIBXML_NOCDATA );

		if ( false === $demo_posts ) {
			return;
		}

		foreach ( $demo_posts as $demo_post ) {
			$the_post = get_page_by_title( $demo_post->title, 'OBJECT' ,'post' );
			if ( null === $the_post ) {
				$new_post['post_type']    = 'post';
				$new_post['post_content'] = $demo_post->content;
				$new_post['post_parent']  = 0;
				$new_post['post_author']  = get_current_user_id();
				$new_post['post_status']  = 'publish';
				$new_post['post_title']   = $demo_post->title;

				$post_id = wp_insert_post( $new_post );

				if ( $post_id && ! is_wp_error( $post_id ) ) {
					wp_set_post_tags( $post_id, $demo_post->tags, true );
				}

				if ( function_exists( 'the_steam_add_featured_image' ) ) {
					/* this function is provided by the plugin */
					the_steam_add_featured_image( $post_id, (string) $demo_post->featured_image );
				}

				if ( isset( $demo_post->categories ) ) {
					$category_slugs = explode( ',', (string) $demo_post->categories );

					$term_ids = array();

					foreach ( $category_slugs as $cat_slug ) {
						if ( false !== ($cat = get_category_by_slug( $cat_slug )) ) {
							array_push( $term_ids, $cat->term_id );
						}
					}

					wp_set_post_categories( $post_id, $term_ids, true );
				}

				if ( ! empty( $demo_post->subtitle ) ) {
					update_post_meta( $post_id, 'post_subtitle', (string) $demo_post->subtitle );
				}
			} elseif ( 'publish' !== get_post_status( $the_post ) ) {
				/* If the page has been hidden, update it. */
				wp_publish_post( $the_post );
			}
		}
	}
}

if ( ! function_exists( 'the_steam_create_demo_dish_types' ) ) {
	/**
	 * This is used to setup demo dish types
	 */
	function the_steam_create_demo_dish_types() {
		/* statically created, no need for an xml here */
		$args = array(
					array(
		'description' => '<p style="text-align: justify">' . esc_html__( 'Whether it`s a quick snack or a light dish choose a starter from our many recipes to open up your appetite', 'thesteam' ) . '</p>',
					      'slug' => esc_html( 'appetizers' ),
					      'name' => esc_html( 'appetizers' ),
					),
					array(
		'description' => '<p style="text-align: justify">' . esc_html__( 'Healthy and traditional dishes cooked by our chefs with fresh, organic and carefully selected ingredients.', 'thesteam' ) . '</p>',
					      'slug' => esc_html( 'main-course' ),
					      'name' => esc_html( 'main course' ),
					),
					array(
		'description' => '<p style="text-align: justify">' . esc_html__( 'At the end of a meal make room for the sweet treat you deserve. The small sin of the day from our large and delicious variety.', 'thesteam' ) . '</p>',
					      'slug' => esc_html( 'desserts' ),
					      'name' => esc_html( 'desserts' ),
					),
					array(
		'description' => '<p style="text-align: justify">' . esc_html__( 'Choose from our variety of deliciously and carefully selected beverages, including milkshakes, specialty coffees and wines.', 'thesteam' ) . '</p>',
									'slug' => esc_html( 'drinks' ),
									'name' => esc_html( 'drinks' ),
					),
		);

		foreach ( $args as $arg ) {
			the_steam_create_demo_dish_type( $arg );
		}
	}
}

if ( ! function_exists( 'the_steam_create_demo_dish_type' ) ) {
	/**
	 * This is used to create a single dish type
	 *
	 * @param array $dish_type Dish type array filled with dish type properties.
	 */
	function the_steam_create_demo_dish_type( $dish_type ) {

		if ( term_exists( strtoupper( $dish_type['name'] ), 'dishtype' ) ) {
			return;
		}

		$args = array(
			'description' => $dish_type['description'],
			'slug' => $dish_type['slug'],
			'parent' => 0,
		);

		$term = wp_insert_term( strtoupper( $dish_type['name'] ), 'dishtype', $args );

		if ( is_wp_error( $term ) ) {
			return;
		}

		$category_meta = get_option( 'taxonomy_term_' . $term['term_id'] );
		$category_meta['taxonomy_id'] = plugins_url() . '/the-steam/demos/img/' . $dish_type['slug'] . '.png';

		update_option( 'taxonomy_term_' . $term['term_id'], $category_meta );
	}
}

if ( ! function_exists( 'the_steam_add_featured_image' ) ) {
	/**
	 * Adds a featured image to a post whatever the post type may be
	 *
	 * @param int    $post_id Post Id.
	 * @param string $file_path File path from where to grab the resource.
	 * @param bool   $attachment_only Attachemnt shout not be set as featured image.
	 *
	 * @return bool Success.
	 */
	function the_steam_add_featured_image( $post_id, $file_path, $attachment_only = false ) {

		$post = null;

		if ( ! $attachment_only ) {
			$post = get_post( $post_id );

			if ( empty( $post ) ) {

				/* Ensure post exists. */
				return false;
			}
		}

		if ( ! class_exists( 'WP_Http' ) ) {
			include_once( plugin_dir_path( __FILE__ ) . '/../../../wp-includes/class-http.php' );
		}

		$photo = new WP_Http();
		$photo = $photo->request( $file_path );

		if ( is_wp_error( $photo ) ) {
			return false;
		}

		if ( 200 !== $photo['response']['code'] ) {
			return false; }

		$attachment = wp_upload_bits( basename( $file_path ), null, $photo['body'], date( 'Y-m', strtotime( $photo['headers']['last-modified'] ) ) );

		if ( ! empty( $attachment['error'] ) ) {
			return false;
		}

		$post_meta = array(
			'post_mime_type'	=> $attachment['type'],
			'post_title'		=> $attachment['file'],
			'post_content'		=> '',
			'post_status'		=> 'inherit',
		);

		$attach_id = wp_insert_attachment( $post_meta, $attachment['file'], $attachment_only ? 0 : $post_id );

		if ( ! function_exists( 'wp_generate_attachment_data' ) ) {
			require_once( plugin_dir_path( __FILE__ ) . '/../../../wp-admin/includes/image.php' );
		}

		$attach_data = wp_generate_attachment_metadata( $attach_id, $attachment['file'] );
		wp_update_attachment_metadata( $attach_id,  $attach_data );

		if ( ! $attachment_only ) {
			set_post_thumbnail( $post_id, $attach_id );
		}

		return $attach_id;
	}
}

add_action( 'plugins_loaded', 'the_steam_plugin_init' );
if ( ! function_exists( 'the_steam_plugin_init' ) ) {
	/**
	 * This loads plugin text domain
	 */
	function the_steam_plugin_init() {
		load_plugin_textdomain( 'thesteam', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
	}
}

register_activation_hook( __FILE__, 'the_steam_install_plugin' );

add_action( 'wp_ajax_the_steam_create_demo_data_2', 'the_steam_create_demo_data_2' );
add_action( 'wp_ajax_nopriv_the_steam_create_demo_data_2', 'the_steam_create_demo_data_2' );

if ( ! function_exists( 'the_steam_create_demo_data_2' ) ) {
	/**
	 * This function is used to create a fully functional demo site
	 * It is the second part of the process
	 */
	function the_steam_create_demo_data_2() {

		if ( ! current_user_can( 'manage_categories' ) ) {
			die( esc_html__( 'Insufficient permissions!', 'thesteam' ) );
		}

		$current_options = get_option( 'the_steam_options' );

		if ( ! is_array( $current_options ) ) {
			$current_options = array();
		}

		$import_options = array(
		'option_cuisine' => 'Mediteranean Cuisine',
		                            'option_enable_dish_types' => 'yes',
		                            'option_currency_after' => 'no',
		                            'option_currency' => '$',
		                            'opening_hours' => '08 am - 10 pm',
		                            'option_enable_dish_types' => 'yes',
									'option_filter_menu_book_disable' => 'no',
									'option_enable_about_section' => 'yes',
		                            'option_enable_menubook' => 'yes',
									'option_parallax_enabled' => 'yes',
		                            'option_carousel_visible' => 'yes',
		                            'option_reservations_enabled' => 'yes',
		                            'option_contact_form' => 'yes',
		                            'option_dish_enabled' => 'yes',
		                            'option_phone_number' => '+01 234 56789',
		                            'option_street' => '111 South Street',
		                            'option_city' => 'New York',
		                            'option_fb_url' => 'facebook.com',
		                            'option_tw_url' => 'twitter.com',
		                            'option_foursquare_url' => 'foursquare.com',
		                            'option_instagram_url' => 'instagram.com',
		                            'option_pinterest_url' => 'pinterest.com',
		                            'option_tripadvisor_url' => 'tripadvisor.com',
		);

		$header_img_id = the_steam_add_featured_image( 0, the_steam_get_default_value( 'import_first_image_url' ), true );

		if ( $header_img_id ) {
			$first_img = wp_get_attachment_image_src( $header_img_id, 'large' );

			if ( is_array( $first_img ) ) {
				set_theme_mod( 'default_header_image', esc_url( $first_img[0] ) );
			}
		}

		$second_img_id = the_steam_add_featured_image( 0, the_steam_get_default_value( 'import_second_image_url' ), true );

		if ( $second_img_id ) {
			$second_img = wp_get_attachment_image_src( $second_img_id, 'large' );

			if ( is_array( $second_img ) ) {
				set_theme_mod( 'the_steam_second_image', esc_url( $second_img[0] ) );
			}
		}

		$fourth_img_id = the_steam_add_featured_image( 0, the_steam_get_default_value( 'import_third_image_url' ), true );

		if ( $fourth_img_id ) {
			$fourth_img = wp_get_attachment_image_src( $fourth_img_id, 'large' );

			if ( is_array( $fourth_img ) ) {
				set_theme_mod( 'the_steam_fourth_image', esc_url( $fourth_img[0] ) );
			}
		}

		$curtain1_img_id = the_steam_add_featured_image( 0, the_steam_get_default_value( 'the_steam_curtain_image1' ), true );

		if ( $curtain1_img_id ) {
			$curtain1_img = wp_get_attachment_image_src( $curtain1_img_id, 'large' );

			if ( is_array( $curtain1_img ) ) {
				set_theme_mod( 'the_steam_curtain_image1', esc_url( $curtain1_img[0] ) );
			}
		}

		$curtain2_img_id = the_steam_add_featured_image( 0, the_steam_get_default_value( 'the_steam_curtain_image2' ), true );

		if ( $curtain2_img_id ) {
			$curtain2_img = wp_get_attachment_image_src( $curtain2_img_id, 'large' );

			if ( is_array( $curtain2_img ) ) {
				set_theme_mod( 'the_steam_curtain_image2', esc_url( $curtain2_img[0] ) );
			}
		}

		$curtain3_img_id = the_steam_add_featured_image( 0, the_steam_get_default_value( 'the_steam_curtain_image3' ), true );

		if ( $curtain3_img_id ) {
			$curtain3_img = wp_get_attachment_image_src( $curtain3_img_id, 'large' );

			if ( is_array( $curtain3_img ) ) {
				set_theme_mod( 'the_steam_curtain_image3', esc_url( $curtain3_img[0] ) );
			}
		}

		$curtain4_img_id = the_steam_add_featured_image( 0, the_steam_get_default_value( 'the_steam_curtain_image4' ), true );

		if ( $curtain4_img_id ) {
			$curtain4_img = wp_get_attachment_image_src( $curtain4_img_id, 'large' );

			if ( is_array( $curtain4_img ) ) {
				set_theme_mod( 'the_steam_curtain_image4', esc_url( $curtain4_img[0] ) );
			}
		}

		$new_options = array_merge( $current_options, $import_options );

		update_option( 'the_steam_options', $new_options );

		the_steam_create_demo_dish_types();
		the_steam_create_demo_dishes();

		die( esc_html__( 'Done!', 'thesteam' ) );
	}
}

add_action( 'wp_ajax_the_steam_create_demo_controls', 'the_steam_create_demo_controls' );
add_action( 'wp_ajax_the_steam_create_demo_controls', 'the_steam_create_demo_controls' );
if (! function_exists('the_steam_create_demo_controls')) {
	function the_steam_create_demo_controls() {
		$the_steam_demo_font_controls = array(

			'01. Frontpage Navigation Bar (Menu) Items' => array( '.navbar .nav > li > a' ),
			'02. Frontpage Header Title line 1' => array( '.logo-first-line' ),
			'03. Frontpage Header Title line 2' => array( '.logo-second-line' ),
			'04. Frontpage Header Title line 3' => array( '.logo-third-line' ),
			'05. Frontpage About Section Title' => array( '#white-section-title' ),
			'06. Frontpage About Section Paragraph' => array( '.about-text' ),
			'07. Frontpage Second Parallax Image Title' => array( '.logo-third-section' ),
			'08. Frontpage Second Parallax Image Subtitle' => array( '.second-image-under-title' ),

			'09. Frontpage Dish-Types Titles' => array( '.dishtype-title' ),
			'10. Frontpage Dish-Types Paragraph' => array( '.dishtype-description' ),

			'11. Frontpage Menu Book Title' => array( '.logo-menu-book-title' ),
			'12. Frontpage Menu Book Subtitle' => array( '.under-menu' ),
			'13. Frontpage Menu Book Food Type Title' => array( '.food-type' ),
			'14. Frontpage Menu Book Dish Title' => array( 'ul.leaders span:first-child' ),
			'15. Frontpage Menu Book Product Description' => array( '.product-description' ),
			'16. Frontpage Menu Book Product Price' => array( '.product-price' ),

			'17. Frontpage Blog Section Title' => array( '.logo-blog' ),
			'18. Frontpage Blog Section Subtitle' => array( '.under-blog' ),
			'19. Frontpage Blog Section Post Title' => array( '.blog-owly-post-title' ),
			'20. Frontpage Blog Section Post Meta' => array( '.post-category-owly', '.owly-post-comments' ),

			'21. Frontpage Reservations Section Title' => array( '.logo-reservation' ),
			'22. Frontpage Reservations Section Subtitle' => array( '#reservations-under-title' ),
			'23. Frontpage Reservations Section Description Title' => array( '.res-right-title' ),
			'24. Frontpage Reservations Section Description Paragraph' => array( '.second-res-row' ),
			'25. Frontpage Reservations Section Phone and E-mail Fields' => array( 'label.phone-number-placeholder', 'label.email-placeholder' ),
			'26. Frontpage Reservations Section Book Button' => array( '.reservations-submit' ),

			'27. Frontpage Map Section Title' => array( '.first-map-line' ),
			'28. Frontpage Map Section Location' => array( '.second-map-line' ),

			'29. Frontpage Footer Section Title' => array( '.logo-footer' ),
			'30. Frontpage Footer Section Subtitles' => array( '.left-title' ),
			'31. Frontpage Footer Section Paragraphs' => array( '.footer-contact' ),
			'32. Frontpage Footer Section Description Paragraph' => array( '.second-res-row' ),
			'33. Frontpage Footer Section Paragraph (instead of contact form)' => array( '.footer-text' ),
			'34. Frontpage Sub-Footer First Line' => array( '.subfooter-first-line' ),
			'35. Frontpage Sub-Footer Second Line' => array( '.blue-text' ),
			'36. Frontpage Sub-Footer Bottom Right Logo' => array( '.footer-bottom-logo' ),

			'37. Blog List and Single Page Navigation Bar (Menu) Items' => array( '.button-fontsize' ),
			'38. Blog List and Single Page Header Title line 1' => array( '.first-logo-line' ),
			'39. Blog List and Single Page Header Title line 2' => array( '.second-logo-line' ),
			'40. Single Page Post Date Line' => array( '.post-date-time' ),
			'41. Single Page Post Category Line' => array( '.post-category-line' ),
			'42. Blog List and Single Page Dish Ingredients Title' => array( '.pre-dish-contents' ),
			'43. Blog List and Single Page Dish Ingredients - Contents' => array( '.dish-contents' ),
			'44. Single Page Text Content' => array( '.blog-post-content' ),
			'45. Single Page Bottom Post Selector Arrows' => array( '.previous-button', '.similar', '.next-button' ),
			'46. Single Page Bottom Post Selector Caption' => array( '.under-selector' ),

			'47. Single Page Comments Title' => array( '#comments' ),
			'48. Single Page Comment Area' => array( '.comment-area' ),
			'49. Single Page Comment Reply Title' => array( '.comment-reply-title' ),
			'50. Single Page Comment Submit Button' => array( 'input[type="submit"]' ),

			'51. Blog List Post Title' => array( '.sticky .post-title-line a', '.post-title-line a' ),
			'52. Blog List Post Meta' => array( '.under-post' ),
			'53. Blog List Post Caption Subtitle' => array( '.post-caption' ),
			'54. Blog List Post Excerpt' => array( '.under-post-text p' ),
			'55. Blog List Read More Button' => array( '.read-more-btn' ),
			'56. Blog List Post Views Count' => array( '.icon-text' ),

		);

		/* Create custom controls for Google Fonts Plugin */
		foreach ( $the_steam_demo_font_controls as $ctrl_name => $ctrl_selectors ) {
			$the_post = get_page_by_title( $ctrl_name, 'OBJECT', 'tt_font_control' );


			if ( null === $the_post ) {
				if ( class_exists( 'EGF_Posttype' ) ) {
					EGF_Posttype::add_font_control( $ctrl_name, $ctrl_selectors, '', true );
				}
			}
		}
	}
}


if ( ! function_exists( 'the_steam_install_plugin' ) ) {
	/**
	 * The install main function for the-steam plugin
	 */
	function the_steam_install_plugin() {

		global $wp_version;
		if ( version_compare( $wp_version, '4.2', '<' ) ) {
			wp_die( esc_html__( 'This plugin requires WordPress version 4.2 or higher.', 'thesteam' ) );
		}

		the_steam_create_reservations_table();
		the_steam_create_demo_controls();
	}
}


if ( ! function_exists( 'the_steam_create_demo_dishes' ) ) {
	/**
	 * Function run at plugin intialization that creates demo dishes
	 */
	function the_steam_create_demo_dishes() {
		$demo_dishes = simplexml_load_file( plugins_url( '/the-steam/demos/export-dishes.xml' ), null, LIBXML_NOCDATA );

		if ( false === $demo_dishes ) {
			return;
		}

		foreach ( $demo_dishes as $demo_dish ) {
			$the_dish = get_page_by_title( $demo_dish->title, 'OBJECT', 'dish' );
			if ( null === $the_dish ) {
				$new_dish['post_type']    = 'dish';
				$new_dish['post_content'] = $demo_dish->content;
				$new_dish['post_parent']  = 0;
				$new_dish['post_author']  = get_current_user_id();
				$new_dish['post_status']  = 'publish';
				$new_dish['post_title']   = $demo_dish->title;

				$post_id = wp_insert_post( $new_dish );

				the_steam_add_featured_image( $post_id, (string) $demo_dish->featured_image );

				update_post_meta( $post_id, 'dish_price', (string) $demo_dish->dish_price );
				update_post_meta( $post_id, 'dish_order', 0 );
				update_post_meta( $post_id, 'dish_contents', (string) $demo_dish->dish_contents );
				wp_set_object_terms( $post_id, (string) $demo_dish->dish_type, 'dishtype', 0 );

				if ( ! empty( $demo_dish->subtitle ) ) {
					update_post_meta( $post_id, 'post_subtitle', (string) $demo_dish->subtitle );
				}
			} elseif ( 'publish' !== get_post_status( $the_dish ) ) {
				/* If the page has been hidden, update it. */
				wp_publish_post( $the_dish );
			}
		}
	}
}

register_deactivation_hook( __FILE__, 'the_steam_uninstall_plugin' );

if ( ! function_exists( 'the_steam_uninstall_plugin' ) ) {
	/**
	 * Function that is run when plugin is deactivated
	 */
	function the_steam_uninstall_plugin() {

		// Nothing to do.
	}
}

if ( ! function_exists( 'the_steam_create_reservations_table' ) ) {
	/**
	 * Create the reservation table at plugin activation if not already created
	 */
	function the_steam_create_reservations_table() {

		global $wpdb;

		$table_name = esc_sql( $wpdb->prefix . 'the_steam_reservations' );

		// Table_name, the only variable used is already sanitised.
		if ( $wpdb->get_var( "show tables like '" . $table_name . "';" ) !== $table_name ) { // WPCS: unprepared SQL ok.

			require_once( plugin_dir_path( __FILE__ ) . '/../../../wp-admin/includes/upgrade.php' );

			dbDelta( "CREATE TABLE $table_name ( id INT NOT NULL AUTO_INCREMENT, rdate DATETIME NOT NULL , remail TINYTEXT NULL , rphone TINYTEXT NOT NULL , rnopers TINYINT NOT NULL , ip TINYTEXT NULL, rdate_added DATETIME NOT NULL, confirmed BOOLEAN NOT NULL DEFAULT FALSE ,UNIQUE (id) )" ); // WPCS: unprepared SQL ok.
		}
	}
}

add_action( 'init', 'the_steam_register_dishtype' );
if ( ! function_exists( 'the_steam_register_dishtype' ) ) {
	/**
	 * Registers the dish as a custom post type with Wordpress
	 */
	function the_steam_register_dishtype() {

		$labels = array(
			'name' => esc_html_x( 'Dish', 'Meal type general name', 'thesteam' ),
			'singular_name' => esc_html_x( 'Dish', 'Meal type singular name', 'thesteam' ),
			'menu_name' => esc_html_x( 'Dishes', 'admin menu', 'thesteam' ),
			'name_admin_bar' => esc_html_x( 'Dish', 'add new on admin bar', 'thesteam' ),
			'add_new' => esc_html_x( 'Add New Dish', 'dish', 'thesteam' ),
			'add_new_item' => esc_html__( 'Add New Dish', 'thesteam' ),
			'new_item' => esc_html__( 'New Dish', 'thesteam' ),
			'edit_item' => esc_html__( 'Edit Dish', 'thesteam' ),
			'view_item' => esc_html__( 'View Dish', 'thesteam' ),
			'all_items' => esc_html__( 'All Dishes', 'thesteam' ),
			'search_items' => esc_html__( 'Search Dishes', 'thesteam' ),
			'parent_item_colon' => esc_html__( 'Parent Dishes:', 'thesteam' ),
			'not_found' => esc_html__( 'No dishes found.', 'thesteam' ),
			'not_found_in_trash' => esc_html__( 'No dishes found in Trash.', 'thesteam' ),
		);

		$args = array(
			'labels' => $labels,
			'public' => true,
			'publicly_queryable' => true,
			'show_ui' => true,
			'show_in_menu' => true,
			'query_var' => true,
			'rewrite' => array( 'slug' => 'dish' ),
			'capability_type' => 'post',
			'map_meta_cap' => true,
			'has_archive' => true,
			'hierarchical' => false,
			'menu_position' => null,
			'supports' => array( 'title', 'thumbnail', 'excerpt', 'comments', 'featured-image', 'editor' ),
		);

		register_post_type( 'dish', $args );

		flush_rewrite_rules();
	}
}

add_action( 'init', 'the_steam_register_dish_taxonomy' );
if ( ! function_exists( 'the_steam_register_dish_taxonomy' ) ) {
	/**
	 * Registers dishtype taxonomy with Wordpress as it is needed to group elements of the custom post type 'dish'
	 */
	function the_steam_register_dish_taxonomy() {

		// Add new taxonomy, make it hierarchical (like categories).
		$labels = array(
			'name' => esc_html__( 'Dish type - Eg: Raw Vegan, Vegetarian', 'thesteam' ),
			'singular_name' => esc_html__( 'Dish type', 'thesteam' ),
			'search_items' => esc_html__( 'Search Dish Types', 'thesteam' ),
			'all_items' => esc_html__( 'All Dish Types', 'thesteam' ),
			'parent_item' => esc_html__( 'Parent Dish Type', 'thesteam' ),
			'parent_item_colon' => esc_html__( 'Parent Dish Type:', 'thesteam' ),
			'edit_item' => esc_html__( 'Edit Dish Type', 'thesteam' ),
			'update_item' => esc_html__( 'Update Dish Type', 'thesteam' ),
			'add_new_item' => esc_html__( 'Add New Dish Type', 'thesteam' ),
			'new_item_name' => esc_html__( 'New Dish Type', 'thesteam' ),
			'menu_name' => esc_html__( 'Dish types', 'thesteam' ),
			'popular_items' => esc_html__( 'Popular dish types', 'thesteam' ),
			'separate_items_with_commas' => esc_html__( 'Separate dish types with commas. Eg: Vegetarian, Raw Vegan etc', 'thesteam' ),
		);

		$args = array(
			'hierarchical' => false,
			'labels' => $labels,
			'show_ui' => true,
			'show_admin_column' => true,
			'query_var' => true,
			'rewrite' => array( 'slug' => 'dishtype' ),
		);

		register_taxonomy( 'dishtype', array( 'dish' ), $args );
		flush_rewrite_rules();
	}
}

add_action( 'init', 'the_steam_enqueue_general_scripts' );
if ( ! function_exists( 'the_steam_enqueue_general_scripts' ) ) {
	/**
	 * Enqueue general scripts like jquery, post share count and comment reply
	 */
	function the_steam_enqueue_general_scripts() {
		wp_enqueue_script( 'thesteam-sharecount', get_template_directory_uri() . '/js/sharecount.js', array( 'jquery' ), null, false );
	}
}

if ( ! function_exists( 'the_steam_valid_email' ) ) {
	/**
	 * Checks wheter the provided e-mail is valid semantically
	 *
	 * @param string $email The value needed to be checked.
	 *
	 * @return bool True if valid, false otherwise
	 */
	function the_steam_valid_email( $email ) {
		if ( false === filter_var( $email, FILTER_VALIDATE_EMAIL ) ) {
			return false;
		}

		return true;
	}
}

if ( ! function_exists( 'the_steam_add_reservation_to_db' ) ) {
	/**
	 * Function used to add a reservation to the reservations table
	 *
	 * @param string $minute Minute of reservation.
	 * @param string $hour Hour  of reservation.
	 * @param string $day Day for reservation.
	 * @param string $month Month of reservation.
	 * @param string $year Year of reservation.
	 * @param string $nopers Number of persons for the table of reservation.
	 * @param string $email Email of the person who does the reservation.
	 * @param string $phone Phone number for contacting person who did the reservation.
	 * @param string $ip IP Address from which the reservation was done - used to prevent spam.
	 *
	 * @return string Last error from the database query
	 */
	function the_steam_add_reservation_to_db( $minute, $hour, $day, $month, $year, $nopers, $email, $phone, $ip ) {
		global $wpdb;

		$table_name = $wpdb->prefix . 'the_steam_reservations';
		$the_date = $year . '-' . $month . '-' . $day . ' ' . $hour . ':' . $minute . ':00';
		$wpdb->insert(
			$table_name,
			array(
				'rdate' => $the_date,
				'remail' => $email,
				'rphone' => $phone,
				'rnopers' => $nopers,
				'ip' => $ip,
				'rdate_added' => the_steam_get_current_time(),
			),
			array(
				'%s',
				'%s',
				'%s',
				'%d',
				'%s',
				'%s',
			)
		);

		return $wpdb->last_error;
	}
}

if ( ! function_exists( 'the_steam_plugin_submit_reservation' ) ) {
	/**
	 * Function used to submit a reservation
	 */
	function the_steam_plugin_submit_reservation() {

		/* Use this to insert data into reservations table created by the plugin. */

		check_ajax_referer( 'the_steam_submit_reservation', 'security' );

		$ip = the_steam_get_sender_ip();

		if ( ! session_id() ) {
			session_start();
		}

		$curr_timestamp = $_SERVER['REQUEST_TIME'];

		/* Session expires in half an hour. */
		$session_timeout = 30 * 60;

		/* Clean session on expiry. */
		if ( isset( $_SESSION['LAST_REQUEST_TIMESTAMP'] ) && ($curr_timestamp - $_SESSION['LAST_REQUEST_TIMESTAMP']) > $session_timeout ) {
			session_unset();
			session_destroy();
			session_start();
			$_SESSION['CLIENT_IP'] = '';
			$_SESSION['LAST_REQUEST_TIMESTAMP'] = 0;
		}

		if ( 'yes' !== the_steam_get_option( 'option_disable_spam_limit' ) ) {
			if ( isset( $_SESSION['CLIENT_IP'] ) && $_SESSION['CLIENT_IP'] === $ip && array_key_exists( 'LAST_REQUEST_TIMESTAMP', $_SESSION ) &&
			     0 < absint( intval( $_SESSION['LAST_REQUEST_TIMESTAMP'] ) ) && ($curr_timestamp - $_SESSION['LAST_REQUEST_TIMESTAMP']) < $session_timeout ) {
				$err_msg = esc_html__( 'Oops! Looks like you already made a reservation just earlier! Please call us to make a reservation or try again later. Thank you!', 'thesteam' );

				die( esc_html( $err_msg ) );
			}
		}

		$_SESSION['LAST_REQUEST_TIMESTAMP'] = $curr_timestamp;
		$_SESSION['CLIENT_IP'] = $ip;

		$email_failsafe = 'notprovided@unused.webdotinc.net';
		$use_email = true;
		$hour = the_steam_sanitize_ajax_field( $_POST['hour'], 'hour' );
		$minute = the_steam_sanitize_ajax_field( $_POST['minute'], 'minute' );
		$day = the_steam_sanitize_ajax_field( $_POST['day'], 'day' );
		$month = the_steam_sanitize_ajax_field( $_POST['month'], 'month' );
		if ( $month < 10 ) { $month = str_replace( '0', '', $month ); }
		$num_pers = the_steam_sanitize_ajax_field( $_POST['num_pers'], 'num_pers' );
		$email = the_steam_sanitize_ajax_field( array_key_exists( 'email', $_POST ) ? $_POST['email'] : $email_failsafe, 'email' );
		if ( the_steam_get_option( 'option_secondary_field' ) === 'name' ) {
			// skip email sanitization, value will be escaped before adding it to db
			$email = $_POST['email'];
			$use_email = false;
		}

		$phone = the_steam_sanitize_ajax_field( $_POST['phone'], 'phone' );
		$year = date( 'Y' );

		the_steam_add_reservation_to_db( $minute, $hour, $day, $month, $year, $num_pers, $email, $phone, $ip );

		if ( 0 === $minute ) { $minute = '00'; }
		if ( 0 === $hour ) { $hour = '00'; }

		$confirmation_msg = esc_html__( 'Thank you for your reservation! We will call you back for confirmation!', 'thesteam' );

		if ( the_steam_valid_email( $email ) && $email_failsafe !== $email ) {
			if ( 'yes' === the_steam_get_option( 'option_received_reservation_sendmail' )  ) {
				global $headers;
				$headers = 'From: ' . esc_html( get_bloginfo( 'name' ) ) . " \r\n";
				$headers .= 'Reply-To: ' . esc_html( get_bloginfo( 'name' ) ) . " \r\n";
				$headers .= 'X-Mailer: PHP/' . phpversion() . "\r\n MIME-Version: 1.0 \r\n Content-type: text/html; charset=iso-8859-1\r\n BCC: ";

				if ( 'yes' !== the_steam_get_option( 'option_use_email_headers' ) ) {
					$headers = '';
				}

				global $subj;
				$subj = the_steam_get_option( 'option_received_reservation_title', '', 9000 );

				if ( ! isset( $subj ) || '' === $subj ) {
					$subj = sprintf( esc_html__( 'Hey! Thank you for your reservation! - %s', 'thesteam' ), esc_url( home_url( '/' ) ) );
				}

				global $body;

				if ( the_steam_get_option( 'option_received_reservation_body' ) !== '' ) {
					$body = wp_kses( the_steam_get_option( 'option_received_reservation_body', '', 9000 ), the_steam_get_valid_theme_kses() );
				} else {
					$body = esc_html__( 'Thank you for your reservation! We will call you back for confirmation!', 'thesteam' );
				}

				try {
					if ( true === $use_email ) {
						wp_mail( $email, $subj, $body, $headers );
					}
				} catch (Exception $e) {
					error_log( 'the_steam_submit_reservation(): '.$e->getMessage()."\n" );
				}
			}
		}

		if ( 'yes' === the_steam_get_option( 'option_received_reservation_send_admin_mail' )  ) {
			$headers = 'From: ' . esc_html( get_bloginfo( 'name' ) ) . " \r\n Reply-To: " . esc_html( get_bloginfo( 'name' ) ) . " \r\n X-Mailer: PHP/" . phpversion() . "\r\n MIME-Version: 1.0 \r\n Content-type: text/html; charset=iso-8859-1\r\n BCC: ";

			if ( 'yes' !== the_steam_get_option( 'option_use_email_headers' ) ) {
				$headers = '';
			}

			$subj = esc_html__( 'New reservation received!', 'thesteam' );

			$body = sprintf( esc_html__( 'You have a new reservation on %s. ', 'thesteam' ), esc_html( get_bloginfo( 'name' ) ) );
			$body .= 'Booking date: ' . $month . '/' . $day . '/' . $year . ' - ' . $hour . ':' . $minute . ' - ' . ' Seats: ' . $num_pers . ', Email: ' . $email . ' | Phone: ' . $phone;
			$body .= ' | Manage booking at ' . esc_url( admin_url( 'admin.php?page=the_steam_view_reservations' ) );
			$admin_email = the_steam_get_option( 'option_email_reservations', get_option( 'admin_email' ), 9000 );

			try {
				wp_mail( $admin_email, $subj, $body, $headers );
			} catch (Exception $e) {
				error_log( 'the_steam_submit_reservation(): '.$e->getMessage()."\n" );
			}
		}

		$confirmation_msg = '<div id="response-reservation-confirmation">' . $confirmation_msg;
		$confirmation_msg .= '</div>';

		die( wp_kses( $confirmation_msg, the_steam_get_valid_theme_kses() ) );
	}
}

if ( ! function_exists( 'the_steam_check_theme_is_active' ) ) {
	/**
	 * This function is used to check if The Steam theme is active
	 *
	 * @return bool True if theme is active, false otherwise
	 */
	function the_steam_check_theme_is_active() {

		$theme = wp_get_theme();
		if ( 'TheSteam' === $theme->name || 'TheSteam' === $theme->parent_theme ) {
			return true;
		}

		return false;
	}
}

add_action( 'admin_menu', 'the_steam_create_plugin_menu' );
if ( ! function_exists( 'the_steam_create_plugin_menu' ) ) {
	/**
	 * This function is used to add menu pages to the admin menu
	 */
	function the_steam_create_plugin_menu() {

		if ( ! the_steam_check_theme_is_active() ) {
			return;
		}

		// This is for the steam reservations.
		$pending_reservations = the_steam_get_pending_reservations_count();

		$bubble_notification = '';

		if ( $pending_reservations ) {
			$bubble_notification = ' <span class=\'update-plugins count-1\'><span class=\'update-count\'>' . absint( $pending_reservations ) . '</span></span><span>';
		}

		$title = esc_html__( 'Reservations - The Steam', 'thesteam' );
		$name = esc_html__( 'Reservations', 'thesteam' );
		$res_page = add_menu_page($title, $name . $bubble_notification, 'manage_options', 'the_steam_view_reservations',
		'the_steam_view_reservations');

		add_action( 'dishtype_edit_form_fields', 'the_steam_enqueue_admin_dependencies' );
		add_action( 'dishtype_add_form_fields', 'the_steam_enqueue_admin_dependencies' );

		add_action( 'load-' . $res_page, 'the_steam_load_admin_scripts' );
	}
}

if ( ! function_exists( 'the_steam_mark_reservation_as' ) ) {
	/**
	 * Marks a reservation as accepted or not
	 *
	 * @param int    $id ID of the reservation.
	 * @param string $confirmed Confirmed or not.
	 */
	function the_steam_mark_reservation_as( $id, $confirmed ) {
		if ( ! current_user_can( 'edit_theme_options' ) ) {
			die( esc_html__( 'You are not allowed to change reservations!', 'thesteam' ) );
		}

		global $wpdb;

		$table_name = $wpdb->prefix . 'the_steam_reservations';

		$wpdb->update(
			$table_name,
			array(
				'confirmed' => $confirmed,
			),
			array( 'ID' => $id ),
			array(
				'%d',
			),
			array( '%d' )
		);
	}
}

if ( ! function_exists( 'the_steam_get_reservations_up_to_date' ) ) {
	/**
	 * Retrieve all reservations up to the moment
	 *
	 * @return array|null|object Reservations, regardless of their state
	 */
	function the_steam_get_reservations_up_to_date() {

		if ( ! current_user_can( 'edit_theme_options' ) ) {
			die( esc_html__( 'You are not allowed to access reservations!', 'thesteam' ) );
		}

		global $wpdb;

		$table_name = esc_sql( $wpdb->prefix . 'the_steam_reservations' );

		$results = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $table_name WHERE DATE(rdate) >= DATE(%s) AND confirmed = 0;", esc_sql( current_time( 'mysql' ) ) ) ); // WPCS: unprepared SQL ok.

		return $results;
	}
}

if ( ! function_exists( 'the_steam_get_reservations_for_date' ) ) {
	/**
	 * Retrieve reservations for given date
	 *
	 * @param string $date Date for which reservations should be retrieved.
	 * @param bool   $confirmed Whether confirmed reservations are to be retrieved.
	 *
	 * @return array|null|object
	 */
	function the_steam_get_reservations_for_date( $date, $confirmed = false ) {
		if ( ! current_user_can( 'edit_theme_options' ) ) {
			die( esc_html__( 'You are not allowed to get reservations!', 'thesteam' ) );
		}

		global $wpdb;

		$table_name = esc_sql( $wpdb->prefix . 'the_steam_reservations' );

		$end = true === $confirmed ? ' AND confirmed = 1; ' : ';';

		$results = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $table_name WHERE DATE(rdate) = DATE(%s) $end", $date ) ); // WPCS: unprepared SQL ok.

		return $results;
	}
}

if ( ! function_exists( 'the_steam_get_pending_reservations_count' ) ) {
	/**
	 * Retrieve number of pending reservations
	 *
	 * @return int Number of pending reservations
	 */
	function the_steam_get_pending_reservations_count() {

		if ( ! current_user_can( 'edit_theme_options' ) ) {
			return 0;
		}

		global $wpdb;

		$table_name = esc_sql( $wpdb->prefix . 'the_steam_reservations' );

		$results = $wpdb->get_results( $wpdb->prepare( "SELECT COUNT(id) as NUMBER_RES FROM $table_name WHERE DATE(rdate) >= DATE(%s) AND confirmed = %d;", esc_sql( current_time( 'mysql' ) ), 0 ) ); // WPCS: unprepared SQL ok.

		if ( isset( $results[0] ) ) {
			return $results[0]->NUMBER_RES;
		} else {
			return 0;
		}
	}
}

if ( ! function_exists( 'the_steam_get_reservations' ) ) {
	/**
	 * Retrieve reservations is a generic function
	 *
	 * @param bool $confirmed Whether it should look for confirmed reservations.
	 *
	 * @return array|null|object Reservations that were extracted
	 */
	function the_steam_get_reservations( $confirmed = false ) {
		if ( ! current_user_can( 'edit_theme_options' ) ) {
			die( esc_html__( 'You are not allowed to change reservations!', 'thesteam' ) );
		}

		global $wpdb;

		$table_name = esc_sql( $wpdb->prefix . 'the_steam_reservations' );
		$conf = $confirmed ? 1 : 0;

		$results = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $table_name WHERE confirmed = %d;", $conf ) ); // WPCS: unprepared SQL ok.

		return $results;
	}
}

if ( ! function_exists( 'the_steam_get_current_time' ) ) {
	/**
	 * Retrieves current database timestamp
	 *
	 * @return int|string Database timestamp
	 */
	function the_steam_get_current_time() {

		return esc_sql( current_time( 'mysql' ) );
	}
}

if ( ! function_exists( 'the_steam_get_reservations_list' ) ) {
	/**
	 * Retrieves html with sorted reservations
	 *
	 * @param bool   $confirmed Whether the reservations should be confirmed.
	 * @param string $date Optional, if given reservations will be retrieved up to specified date.
	 *
	 * @return string Html formatted text that contains a list of reservations
	 */
	function the_steam_get_reservations_list( $confirmed = false, $date = 'NO_DATE' ) {
		if ( 'NO_DATE' !== $date && 'uptodate' !== $date ) {
			$results = the_steam_get_reservations_for_date( $date, $confirmed );
		} elseif ( 'uptodate' === $date ) {
			$results = the_steam_get_reservations_up_to_date();
		} else {
			$results = the_steam_get_reservations( $confirmed );
		}

		return the_steam_get_all_reservations_box( $results );
	}
}

if ( ! function_exists( 'the_steam_get_current_reservations_box' ) ) {
	/**
	 * Retrieves a html formatted header for the reservation
	 *
	 * @return string Html formatted text
	 */
	function the_steam_get_current_reservations_box() {

		$string = '<h3 class="ts-underline">'.esc_html__( 'Confirmed for today', 'thesteam' ).'</h3>';
		$string .= the_steam_get_reservations_list( true, the_steam_get_current_time() );
		$string .= '<hr/><h3 class="ts-underline">'.esc_html__( 'All pending reservations', 'thesteam' ).'</h3>';
		$string .= the_steam_get_reservations_list( false, 'uptodate' );

		return $string;
	}
}

if ( ! function_exists( 'the_steam_view_reservations' ) ) {
	/**
	 * Prints out a list full of reservations
	 */
	function the_steam_view_reservations() {

		if ( ! current_user_can( 'edit_theme_options' ) ) {
			die( esc_html__( 'You are not allowed to change reservations!', 'thesteam' ) );
		}

		if ( 'no' === the_steam_get_option( 'option_reservations_enabled' ) ) {
			echo '<h2> ' . esc_html__( 'Reservations are not enabled!', 'thesteam' ) .'</h2>
        <p>' . esc_html__( 'You can enable them on the theme settings page.', 'thesteam' ) . " <a href='" . esc_url( admin_url( 'admin.php?page=the_steam_view_settings#settings-tabs-3' ) ) . "'>" . esc_html__( 'See more', 'thesteam' ) . '</a></p>';
			return;
		}
		?>
		<div id="tabs">
			<ul>
				<li><a href="#tabs-1"><?php esc_html_e( 'Current reservations', 'thesteam' ); ?></a></li>
				<li><a href="#tabs-2"><?php esc_html_e( 'All reservations', 'thesteam' ); ?></a></li>
			</ul>
			<div id="tabs-1">
				<div class='wrap reservations_box'>
					<?php
					echo wp_kses( the_steam_get_current_reservations_box(), the_steam_get_valid_theme_kses() );
					?>
				</div>
			</div>
			<div id="tabs-2">
				<div>
					<p><?php esc_html_e( 'Date:', 'thesteam' ); ?> <input type="text" id="datepicker"/></p>

					<div id="all-reservations">
						<!-- Reservations list content is filled here through AJAX. -->
					</div>
				</div>
			</div>
		</div>
		<?php
	}
}

/* Mailgun and others don't fill in header types correctly. */
add_filter( 'wp_mail_content_type', 'the_steam_set_mail_content_type' );
if ( ! function_exists( 'the_steam_set_mail_content_type' ) ) {
	/**
	 * Sets up default mail content type
	 *
	 * @param string $content_type Unused.
	 *
	 * @return string Plugin desired content type
	 */
	function the_steam_set_mail_content_type( $content_type ) {
		return 'text/html';
	}
}


add_action( 'wp_ajax_the_steam_submit_reservations_change', 'the_steam_submit_reservations_change' );
if ( ! function_exists( 'the_steam_submit_reservations_change' ) ) {
	/**
	 * Sends e-mail with confirmation after the reservation is accepted or denied in the admin menu
	 */
	function the_steam_submit_reservations_change() {

		if ( ! current_user_can( 'edit_theme_options' ) ) {
			die( esc_html__( 'You are not allowed to change reservations!', 'thesteam' ) );
		}

		check_ajax_referer( 'the_steam_submit_reservations_change', 'security' );
		$id = the_steam_sanitize_ajax_field( $_POST['id'], 'id' );
		$checked = 'true' === $_POST['checked'] ? 1 : 0;

		the_steam_mark_reservation_as( $id, $checked );

		if ( 1 === $checked  ) {
			if ( the_steam_get_option( 'option_accepted_reservation_sendmail' ) === 'yes' ) {

				global $wpdb;

				$table_name = esc_sql( $wpdb->prefix . 'the_steam_reservations' );

				$result = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $table_name WHERE id = %d", $id ) ); // WPCS: unprepared SQL ok.

				$email = $result[0]->remail;

				/* Headers cannot be translated */
				$headers = 'From: ' . esc_html( get_bloginfo( 'name' ) ). " \r\n";
				$headers .= 'Reply-To: ' . esc_html( get_bloginfo( 'name' ) ). " \r\n X-Mailer: PHP/" . phpversion() . "\r\n MIME-Version: 1.0 \r\n Content-type: text/html; charset=iso-8859-1\r\n BCC: ";

				if ( 'yes' !== the_steam_get_option( 'option_use_email_headers' ) ) {
					$headers = '';
				}

				$subj = esc_html( the_steam_get_option( 'option_accepted_reservation_title', 'Reservation confirmed!', 9000 ) );

				$body = '';

				if ( '' !== the_steam_get_option( 'option_accepted_reservation_body' ) ) {
					$body .= wp_kses( the_steam_get_option( 'option_accepted_reservation_body', '', 9000 ), the_steam_get_valid_theme_kses() );
				} else {
					$body .= esc_html__( 'Your reservation has been confirmed! Thank you and are we are looking forward to seeing you!', 'thesteam' );
				}

				try {
					wp_mail( $email, $subj, $body, $headers );
				} catch (Exception $e) {
					error_log( 'the_steam_submit_reservations_change(): '.$e->getMessage()."\n" );
				}
			}
		}

		die( wp_kses( the_steam_get_current_reservations_box(), the_steam_get_valid_theme_kses() ) );
	}
}

if ( ! function_exists( 'the_steam_get_db_date_from_date_picker' ) ) {
	/**
	 * Retrieves date in database format from jquery ui datepicker
	 *
	 * @param string $date Date in jqueryui picker default format.
	 *
	 * @return string Date in database format
	 */
	function the_steam_get_db_date_from_date_picker( $date ) {
		/**
		 * All this because the JQuery UI DatePicker
		 * format change and selection callback
		 * don't play well with each other
		 * selection cb requires $( "#datepicker" ).removeClass('hasDatepicker')
		 * which will wipe out new format although set on next line.
		 */
		$chunx = explode( '/', $date );

		$month = $chunx[0];
		$day = $chunx[1];
		$year = $chunx[2];

		$db_date = $year . '-' . $month . '-' . $day;

		return $db_date;
	}
}

add_action( 'wp_ajax_the_steam_submit_reservations_date_change', 'the_steam_submit_reservations_date_change' );

if ( ! function_exists( 'the_steam_submit_reservations_date_change' ) ) {
	/**
	 * Submits reservation date when changed
	 */
	function the_steam_submit_reservations_date_change() {

		if ( ! current_user_can( 'edit_theme_options' ) ) {
			die( esc_html__( 'You are not allowed to submit reservations changes!', 'thesteam' ) );
		}

		check_ajax_referer( 'the_steam_submit_reservations_date_change', 'security' , false );

		$date = the_steam_sanitize_ajax_field( $_POST['date'], 'date' );

		$date = the_steam_get_db_date_from_date_picker( $date );

		$res = the_steam_get_reservations_for_date( $date );

		die( wp_kses( the_steam_get_all_reservations_box( $res ), the_steam_get_valid_theme_kses() ) );
	}
}

if ( ! function_exists( 'the_steam_get_all_reservations_box' ) ) {
	/**
	 * Retrieves all reservation box as html formatted text for the admin menu
	 *
	 * @param array $results Reservations from database.
	 *
	 * @return string Html formatted admin box
	 */
	function the_steam_get_all_reservations_box( $results ) {

		$string = '
    <table class="reservations-table">
    <tr>
        <th class="all-reservations-header">'.esc_html__( 'IP', 'thesteam' ) .'</th>
        <th class="all-reservations-header">'. ('name' === the_steam_get_option( 'option_secondary_field' ) ? esc_html__( 'Name', 'thesteam' ) : esc_html__( 'E-Mail', 'thesteam' )) .'</th>
        <th class="all-reservations-header">'.esc_html__( 'Phone', 'thesteam' ) .'</th>
        <th class="all-reservations-header">'.esc_html__( 'Seats', 'thesteam' ) .'</th>
        <th class="all-reservations-header">'.esc_html__( 'Added', 'thesteam' ) .'</th>
        <th class="all-reservations-header">'.esc_html__( 'Reservation', 'thesteam' ) .'</th>
        <th class="all-reservations-header">'.esc_html__( 'Confirmed', 'thesteam' ) .'</th>
    </tr>
    ';

		if ( empty( $results ) ) {
			$string .= "<tr class='res-table-row'>
                            <td class='empty-result'> - </td>
                            <td class='empty-result'> - </td>
                            <td class='empty-result'> - </td>
                            <td class='empty-result'> - </td>
                            <td class='empty-result'> - </td>
                            <td class='empty-result'> - </td>
                            <td class='empty-result'> - </td>
                        </tr>";
		}

		foreach ( $results as $result ) {
			$string .= '
                <tr  class="res-admin-tr" >
                    <td>' . $result->ip . '</td>
                    <td>' . $result->remail . '</td>
                    <td>' . $result->rphone . '</td>
                    <td>' . $result->rnopers . '</td>
                    <td>' . $result->rdate_added . '</td>
                    <td>' . $result->rdate . '</td>
                    <td><input type="checkbox" value="' . $result->id . '" class="confirmedCheckbox" ';

			if ( $result->confirmed ) {
				$string .= 'checked';
			}

			$string .= '></td>
                </tr>
                ';
		}
		$string .= '</table>';

		return $string;
	}
}

if ( ! function_exists( 'the_steam_dish_tax_term_box' ) ) {
	/**
	 * Renders dish term box
	 *
	 * @param WP_Post $object The post.
	 */
	function the_steam_dish_tax_term_box( $object ) {
		wp_nonce_field( 'the_steam_submit_dish_tax_term', 'ts-meta-box-dishtype' );

		$args = array(
			'taxonomy' => 'dishtype',
			'order' => 'ASC',
			'orderby' => 'name',
			'hide_empty' => 0,
		);

		$category_list = get_categories( $args );

		// No dish type defined or invalid dish type.
		if ( isset( $category_list['errors'] ) || empty( $category_list ) ) {
			esc_html_e( 'Looks like you have not defined any dish types yet! Please define at least one!', 'thesteam' );
			return;
		}

		$term = wp_get_post_terms( $object->ID, 'dishtype' );

		?>
		<select class="meta-box-width" name="the_steam_dish_tax_term" id="dish_term">
			<?php
			foreach ( $category_list as $el ) {
				echo '<option';
				if ( isset( $term[0] ) && ($term[0]->name === $el->name) ) {
					echo ' selected';
				}
				echo ' value="' . esc_attr( $el->name ) . '">' . esc_attr( $el->name ) . '</option>';
			}
			?>
		</select>
		<?php
	}
}

if ( ! function_exists( 'the_steam_print_current_selected_dishtype' ) ) {
	/**
	 * Function used to print the dish type currently selected
	 */
	function the_steam_print_current_selected_dishtype() {

		echo esc_html( get_query_var( 'dishtype' ) ? the_steam_get_elipsis( get_query_var( 'dishtype' ), 30 )  : esc_html__( 'All Dishes', 'thesteam' ) );
	}
}

if ( ! function_exists( 'the_steam_setup_dish_query' ) ) {
	/**
	 * Function used to setup the dish query
	 */
	function the_steam_setup_dish_query() {

		$the_steam_is_dishtype_query = ( get_query_var( 'dishtype' ) ) ? get_query_var( 'dishtype' ) : 0;

		$the_steam_dishlist_query_args = array(
			'post_type'      => 'dish',
			'posts_per_page' => get_option( 'posts_per_page' ),
			'dishtype'       => $the_steam_is_dishtype_query,
			'paged'          => ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1,
		);

		/**
		 * Yes, we really do want to use query_posts here!
		 * We need pagination and all for the custom posts
		 * rendered in the page dedicated to this custom taxonomy!
		 */
		query_posts( $the_steam_dishlist_query_args );
	}
}

/**
 * Required by TinyMCE when editing term description.
 * This allows saving taxonomy description with
 * user chosen styles from TinyMCE. This requirement
 * was imposed by the envato reviewer, so the user
 * can choose text appearance and styling for tax description.
 * At taxonomy creation and in wordpress customizer it is not
 * possible to reliably enqueue tinymce editor.
 */
remove_filter( 'pre_term_description', 'wp_filter_kses' );
remove_filter( 'term_description', 'wp_kses_data' );
add_filter( 'manage_edit-dishtype_columns', 'the_steam_dishtype_term_columns' );
if ( ! function_exists( 'the_steam_dishtype_term_columns' ) ) {
	/**
	 * Sets table headers for the taxonomy dishtype
	 *
	 * @param array $theme_columns Default columns.
	 *
	 * @return array Theme columns
	 */
	function the_steam_dishtype_term_columns( $theme_columns ) {
		$new_columns = array(
			'cb' => '<input type="checkbox" />',
			'name' => esc_html__( 'Name', 'thesteam' ),
			'featured_image' => esc_html__( 'Featured Image', 'thesteam' ),
			'description' => esc_html__( 'Description', 'thesteam' ),
			'slug' => esc_html__( 'Slug', 'thesteam' ),
			'count' => esc_html__( 'Count', 'thesteam' ),
		);
		return $new_columns;
	}
}

add_filter( 'manage_dishtype_custom_column', 'the_steam_manage_term_columns', 10, 3 );
if ( ! function_exists( 'the_steam_manage_term_columns' ) ) {
	/**
	 * Renders table cell image for the dishtype list
	 *
	 * @param string $out Table cell content with image.
	 * @param string $column_name Column name as defined above.
	 * @param int    $term_id Taxonomy term id.
	 *
	 * @return string Table cell content
	 */
	function the_steam_manage_term_columns( $out, $column_name, $term_id ) {
		switch ( $column_name ) {
			case 'featured_image':
				$term_meta = get_option( 'taxonomy_term_' . $term_id );
				$out .= "<img alt=\"category image\" src='" . ($term_meta['taxonomy_id'] ? $term_meta['taxonomy_id'] : '#') . "' height='50' width='65'/>";
				break;

			default:
				break;
		}
		return $out;
	}
}

add_action( 'admin_head', 'remove_default_dishtype_description' );
if ( ! function_exists( 'remove_default_dishtype_description' ) ) {
	/**
	 * Removes buttons in a cross-version compatible way
	 * Displaying buttons by providing them to 'toolbarX'
	 * and renders the editor unusable in some versions.
	 */
	function remove_default_dishtype_description() {
		global $current_screen;
		if ( 'edit-dishtype' === $current_screen->id ) {
			/*
			 The only cross-version compatible way to remove default Tiny MCE
			 * default edit box.
			 * Wp_editor enqueued any place other than
			 * the posts page brings nothing but trouble. But if this
			 * is what has been requested at review, it needs to be done.
			 * Won't add yet another js file to improve reaction and load times
			 */
			?>
			<script type="text/javascript">
				jQuery(function ($) {
					window.setTimeout(function () {
						$('.mce-i-blockquote, .mce-i-numlist, .mce-i-bullist, ' +
							'.mce-i-hr, .mce-i-fullscreen, .mce-i-link, .mce-i-unlink').parent().parent().css({'display': 'none'});
					}, 1000);
					$('#wp-description-wrap').remove();
					$('#wp-tag-description-wrap').remove();
					$('.mce-i-blockquote').css({'display': 'none'});
				});
			</script>
			<?php
		}
	}
}

add_filter( 'mce_buttons', 'the_steam_enable_tiny_mce_justify', 5 );
if ( ! function_exists( 'the_steam_enable_tiny_mce_justify' ) ) {
	/**
	 * Addes necesarry buttons for alignment
	 *
	 * @param array $btn_list Tiny-mce buttons list.
	 *
	 * @return array Buttons list with align right and justify included
	 */
	function the_steam_enable_tiny_mce_justify( $btn_list ) {

		if ( ! in_array( 'alignjustify', $btn_list ) ) {
			$location = array_search( 'alignright', $btn_list, false );
			if ( false !== $location ) {
				$justify_btn = array( 'alignjustify' );
				array_splice( $btn_list, $location + 1, 0, $justify_btn );
			}
		}

		return $btn_list;
	}
}

// This helps print out in the edit taxonomy menu.
add_action( 'dishtype_edit_form_fields', 'the_steam_dishtype_taxonomy_edit_custom_fields', 10, 2 );
if ( ! function_exists( 'the_steam_dishtype_taxonomy_edit_custom_fields' ) ) {
	/**
	 * Renders the taxonomy dishtype menu
	 *
	 * @param WP_Term $tag The term.
	 */
	function the_steam_dishtype_taxonomy_edit_custom_fields( $tag ) {

		wp_nonce_field( 'dishtype_add_form_fields', 'add_form_fields' );

		$t_id = $tag->term_id;
		$term_meta = get_option( 'taxonomy_term_' . $t_id );
		?>
		<tr class="form-field">
			<th scope="row" class="category-align-top">
				<label for="dishtype"><?php esc_html_e( 'Image', 'thesteam' ); ?></label>
			</th>
			<td colspan="2">
				<input type="text"
					   name="term_meta[taxonomy_id]" id="term_meta[taxonomy_id]"
					   class="taxonomy-image-url"
					   value="<?php echo esc_attr( $term_meta['taxonomy_id'] ? $term_meta['taxonomy_id'] : '' ); ?>"/>
			</td>
		</tr>
		<tr class="category-align-top">
			<td valign="top">
				<a href="#" class="button-primary taxonomy-image-upload"><?php esc_html_e( 'Select', 'thesteam' ); ?></a>
			</td>
			<td valign="top">
				<img class="taxonomy-image" alt="<?php esc_html_e( 'Please select or upload an image', 'thesteam' ); ?>"
				     src="<?php echo esc_url( $term_meta['taxonomy_id'] ? $term_meta['taxonomy_id'] : '' ); ?>"
				     height="200"
				     width="300"/>
			</td>
		</tr>
		<tr>
			<td colspan="2">
				<?php wp_editor( wp_kses_post( $tag->description , ENT_QUOTES, 'UTF-8' ), 'description', array( 'wp_autop' => true, 'media_buttons' => false, 'quicktags' => false ) ); ?>
			</td>
		</tr>
		<?php
		$tax_img_upload_data = array( 'dialogTitle' => esc_html__( 'Custom Image', 'thesteam' ), 'dialogText' => esc_html__( 'Select Image', 'thesteam' ) );
		wp_register_script( 'thesteam-taxonomy-image-upload', esc_url( get_template_directory_uri() . '/js/taxonomy-image-upload.js' ), array( 'jquery' ), null );
		wp_localize_script( 'thesteam-taxonomy-image-upload', 'taxImgUploadData', $tax_img_upload_data );
		wp_enqueue_script( 'thesteam-taxonomy-image-upload' );
	}
}

add_action( 'dishtype_add_form_fields', 'the_steam_dishtype_taxonomy_add_custom_fields', 10, 2 );
// This helps print out in the add new taxonomy menu.
if ( ! function_exists( 'the_steam_dishtype_taxonomy_add_custom_fields' ) ) {
	/**
	 * Renders the add new taxonomy menu
	 */
	function the_steam_dishtype_taxonomy_add_custom_fields() {

		wp_nonce_field( 'dishtype_add_form_fields', 'add_form_fields' );

		$tax_args = array(
			'order' => 'ASC',
			'hide_empty' => 0,
		);
		/* We really need to use get_terms here */
		$terms = get_terms( 'dishtype', $tax_args );

		if ( count( $terms ) >= 4 && 'yes' === the_steam_get_option( 'option_4_main_categories', 'no' ) ) {
			?>
			<p class="dish-custom-color">
				<b><?php esc_html_e( 'You already have the maximum number of dish types defined! Please consider removing some before you add any new one! Only first 4 are displayed!', 'thesteam' ); ?></b>
			</p>
			<?php
			return;
		}
		?>
		<tr class="form-field">
			<th scope="row" class="category-align-top">
				<label for="dishtype"><?php esc_html_e( 'Image', 'thesteam' ); ?></label>
			</th>
		</tr>
		<tr>
			<td>
				<input type="text"
					   name="term_meta[taxonomy_id]" id="term_meta[taxonomy_id]"
					   class="taxonomy-image-url"
					   value=""/>
			</td>
		</tr>
		<tr>
			<td>
				<a href="#" class="button-primary ts-button-primary taxonomy-image-upload"><?php esc_html_e( 'Browse gallery', 'thesteam' ); ?></a>
			</td>
		</tr>
		<tr>
			<td>
				<img class="taxonomy-image" alt="<?php esc_html_e( 'Please select or upload an image', 'thesteam' ); ?>" src="" height="200" width="300"/>
			</td>
		</tr>
		<?php

		$tax_img_upload_data = array( 'dialogTitle' => esc_html__( 'Custom Image', 'thesteam' ), 'dialogText' => esc_html__( 'Select Image', 'thesteam' ) );
		wp_register_script( 'thesteam-taxonomy-image-upload', esc_url( get_template_directory_uri() . '/js/taxonomy-image-upload.js' ), array( 'jquery' ), null );
		wp_localize_script( 'thesteam-taxonomy-image-upload', 'taxImgUploadData', $tax_img_upload_data );
		wp_enqueue_script( 'thesteam-taxonomy-image-upload' );
	}
}

add_action( 'edited_dishtype', 'the_steam_save_taxonomy_custom_fields', 10, 2 );
add_action( 'create_dishtype', 'the_steam_save_taxonomy_custom_fields', 10, 2 );
if ( ! function_exists( 'the_steam_save_taxonomy_custom_fields' ) ) {
	/**
	 * Saves custom theme taxonomy dishtype featured image
	 *
	 * @param int $term_id Term id.
	 */
	function the_steam_save_taxonomy_custom_fields( $term_id ) {

		if ( ! current_user_can( 'manage_categories' ) ) {
			return;
		}

		if ( ! isset( $_POST ) || ! isset( $_POST['add_form_fields'] ) || ! wp_verify_nonce( $_POST['add_form_fields'], 'dishtype_add_form_fields' ) ) {
			return;
		}

		if ( isset( $_POST['term_meta'] ) ) {
			$t_id = $term_id;
			$term_meta = get_option( 'taxonomy_term_' . $t_id );
			$cat_keys = array_keys( $_POST['term_meta'] );
			foreach ( $cat_keys as $key ) {
				if ( isset( $_POST['term_meta'][ $key ] ) ) {
					$term_meta[ $key ] = sanitize_text_field( $_POST['term_meta'][ $key ] );
				}
			}
			// Save the option array.
			update_option( 'taxonomy_term_' . $t_id, $term_meta );
		}
	}
}

if ( ! function_exists( 'the_steam_dish_description_box' ) ) {
	/**
	 * Renders dish description metabox (SEO)
	 *
	 * @param WP_Post $object The post.
	 */
	function the_steam_dish_description_box( $object ) {
		wp_nonce_field( 'the_steam_submit_dish_description', 'ts-meta-box-dish-description' );

		$dish_description = get_post_meta( $object->ID, 'dish_description', 'true' );
		?>
		<textarea class="meta-box-width"
		          name="the_steam_dish_description"><?php echo esc_textarea( $dish_description ); ?></textarea>

		<?php
	}
}

add_action( 'save_post', 'the_steam_save_dish_description_meta_box', 10, 3 );
if ( ! function_exists( 'the_steam_save_dish_description_meta_box' ) ) {
	/**
	 * Saves dish description meta box (SEO)
	 *
	 * @param int     $post_id Post id.
	 * @param WP_Post $post The post.
	 * @param bool    $update Updating existing post or not.
	 *
	 * @return int Post id
	 */
	function the_steam_save_dish_description_meta_box( $post_id, $post, $update ) {
		if ( ! isset( $_POST ) || ! isset( $_POST['ts-meta-box-dish-description'] ) || ! wp_verify_nonce( $_POST['ts-meta-box-dish-description'], 'the_steam_submit_dish_description' ) ) {
			return $post_id;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return $post_id;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return $post_id;
		}

		$slug = 'dish';

		if ( $slug !== $post->post_type ) {
			return $post_id;
		}

		if ( isset( $_POST['the_steam_dish_description'] ) ) {
			$meta_box_description = sanitize_text_field( $_POST['the_steam_dish_description'] );
			update_post_meta( $post_id, 'dish_description', $meta_box_description );
		}

		return $post_id;
	}
}

if ( ! function_exists( 'the_steam_dish_contents_box' ) ) {
	/**
	 * Renders dish contents metabox
	 *
	 * @param WP_Post $object The post.
	 */
	function the_steam_dish_contents_box( $object ) {
		wp_nonce_field( 'the_steam_submit_dish_contents', 'ts-meta-box-dish-contents' );

		$dish_contents = get_post_meta( $object->ID, 'dish_contents', 'true' );
		?>
		<textarea class="meta-box-width"
		          name="the_steam_dish_contents"><?php echo esc_textarea( $dish_contents ); ?></textarea>

		<?php
	}
}

add_action( 'save_post', 'the_steam_save_dish_contents_meta_box', 10, 3 );
if ( ! function_exists( 'the_steam_save_dish_contents_meta_box' ) ) {
	/**
	 * Saves dish contents meta box
	 *
	 * @param int     $post_id Post id.
	 * @param WP_Post $post The post.
	 * @param bool    $update Updating existing post or not.
	 *
	 * @return int Post id
	 */
	function the_steam_save_dish_contents_meta_box( $post_id, $post, $update ) {
		if ( ! isset( $_POST ) || ! isset( $_POST['ts-meta-box-dish-contents'] ) || ! wp_verify_nonce( $_POST['ts-meta-box-dish-contents'], 'the_steam_submit_dish_contents' ) ) {
			return $post_id;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return $post_id;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return $post_id;
		}

		$slug = 'dish';

		if ( $slug !== $post->post_type ) {
			return $post_id;
		}

		if ( isset( $_POST['the_steam_dish_contents'] ) ) {
			$meta_box_contents = sanitize_text_field( $_POST['the_steam_dish_contents'] );
			update_post_meta( $post_id, 'dish_contents', $meta_box_contents );
		}

		return $post_id;
	}
}

if ( ! function_exists( 'the_steam_dish_price_box' ) ) {
	/**
	 * Renders dish price box
	 *
	 * @param WP_Post $object The post.
	 */
	function the_steam_dish_price_box( $object ) {
		wp_nonce_field( 'the_steam_submit_dish_price', 'ts-meta-box-dish-price' );

		$dish_price = get_post_meta( $object->ID, 'dish_price', 'true' );

		if ( ! isset( $dish_price ) || '' === $dish_price ) {
			$dish_price = 0;
		}
		?>
		<input type="text" name="the_steam_dish_price" value="<?php echo esc_attr( $dish_price ); ?>"/>

		<?php
	}
}

add_action( 'save_post', 'the_steam_save_dish_price_meta_box', 10, 3 );
if ( ! function_exists( 'the_steam_save_dish_price_meta_box' ) ) {
	/**
	 * Saves dish price metabox value
	 *
	 * @param int     $post_id Post id.
	 * @param WP_Post $post The post.
	 * @param bool    $update Updating existing post or not.
	 *
	 * @return int Post id
	 */
	function the_steam_save_dish_price_meta_box( $post_id, $post, $update ) {
		if ( ! isset( $_POST ) || ! isset( $_POST['ts-meta-box-dish-price'] ) || ! wp_verify_nonce( $_POST['ts-meta-box-dish-price'], 'the_steam_submit_dish_price' ) ) {
			return $post_id;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return $post_id;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return $post_id;
		}

		$slug = 'dish';

		if ( $slug !== $post->post_type ) {
			return $post_id;
		}

		if ( isset( $_POST['the_steam_dish_price'] ) ) {
			$meta_box_price_value = sanitize_text_field( $_POST['the_steam_dish_price'] );
			update_post_meta( $post_id, 'dish_price', $meta_box_price_value );
		}

		return $post_id;
	}
}

if ( ! function_exists( 'the_steam_dish_order_box' ) ) {
	/**
	 * Renders dish order box
	 *
	 * @param WP_Post $object The post.
	 */
	function the_steam_dish_order_box( $object ) {
		wp_nonce_field( 'the_steam_submit_dish_order', 'ts-meta-box-dish-order' );

		$dish_order = get_post_meta( $object->ID, 'dish_order', 'true' );

		if ( ! isset( $dish_order ) || '' === $dish_order ) {
			$dish_order = 0;
		}
		?>
		<input type="text" name="the_steam_dish_order" value="<?php echo esc_attr( $dish_order ); ?>"/>

		<?php
	}
}

add_action( 'save_post', 'the_steam_save_dish_order_meta_box', 10, 3 );
if ( ! function_exists( 'the_steam_save_dish_order_meta_box' ) ) {
	/**
	 * Saves dish order metabox value
	 *
	 * @param int     $post_id Post id.
	 * @param WP_Post $post The post.
	 * @param bool    $update Updating existing post or not.
	 *
	 * @return int Post id
	 */
	function the_steam_save_dish_order_meta_box( $post_id, $post, $update ) {
		if ( ! isset( $_POST ) || ! isset( $_POST['ts-meta-box-dish-order'] ) || ! wp_verify_nonce( $_POST['ts-meta-box-dish-order'], 'the_steam_submit_dish_order' ) ) {
			return $post_id;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return $post_id;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return $post_id;
		}

		$slug = 'dish';

		if ( $slug !== $post->post_type ) {
			return $post_id;
		}

		if ( isset( $_POST['the_steam_dish_order'] ) ) {
			$meta_box_order_value = sanitize_text_field( $_POST['the_steam_dish_order'] );
			update_post_meta( $post_id, 'dish_order', $meta_box_order_value );
		}

		return $post_id;
	}
}

add_action( 'save_post', 'the_steam_save_dish_term_meta_box', 10, 3 );
if ( ! function_exists( 'the_steam_save_dish_term_meta_box' ) ) {
	/**
	 * Saves dish term metabox
	 *
	 * @param int     $post_id Post id.
	 * @param WP_Post $post The post.
	 * @param bool    $update Updating existing post or not.
	 *
	 * @return int Post id
	 */
	function the_steam_save_dish_term_meta_box( $post_id, $post, $update ) {
		if ( ! isset( $_POST ) || ! isset( $_POST['ts-meta-box-dishtype'] ) || ! wp_verify_nonce( $_POST['ts-meta-box-dishtype'], 'the_steam_submit_dish_tax_term' ) ) {
			return $post_id;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return $post_id;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return $post_id;
		}

		$slug = 'dish';

		if ( $slug !== $post->post_type ) {
			return $post_id;
		}

		if ( isset( $_POST['the_steam_dish_tax_term'] ) ) {
			$meta_box_dropdown_value = sanitize_text_field( $_POST['the_steam_dish_tax_term'] );
			wp_set_object_terms( $post->ID, $meta_box_dropdown_value, 'dishtype', 0 );
		}

		return $post_id;
	}
}

if ( ! function_exists( 'the_steam_dish_subtitle_box' ) ) {
	/**
	 * Prints out theme's subtitle box
	 *
	 * @param WP_Post $object The post.
	 */
	function the_steam_dish_subtitle_box( $object ) {
		wp_nonce_field( 'the_steam_submit_dish_subtitle', 'ts-meta-box-dish-subtitle' );

		$dish_subtitle = get_post_meta( $object->ID, 'dish_subtitle', 'true' );
		?>
		<input id="the-steam-dish-subtitle" type="text" maxlength="200" name="the_steam_dish_subtitle"
		       value="<?php echo esc_attr( $dish_subtitle ); ?>"/>

		<?php
	}
}


add_action( 'save_post', 'the_steam_save_dish_subtitle_metabox', 10, 3 );
if ( ! function_exists( 'the_steam_save_dish_subtitle_metabox' ) ) {
	/**
	 * Saves data from the subtitle metabox for the custom post type 'dish'
	 *
	 * @param int     $post_id Post ID.
	 * @param WP_Post $post The post.
	 * @param bool    $update Existing post being updated or not.
	 *
	 * @return int Post ID
	 */
	function the_steam_save_dish_subtitle_metabox( $post_id, $post, $update ) {
		if ( ! isset( $_POST ) || ! isset( $_POST['the_steam_dish_subtitle'] ) || ! wp_verify_nonce( $_POST['ts-meta-box-dish-subtitle'], 'the_steam_submit_dish_subtitle' ) ) {
			return $post_id;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return $post_id;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return $post_id;
		}

		$slug = 'dish';

		if ( $slug !== $post->post_type ) {
			return $post_id;
		}

		if ( isset( $_POST['the_steam_dish_subtitle'] ) ) {
			$meta_box_dish_subtitle = sanitize_text_field( $_POST['the_steam_dish_subtitle'] );
			update_post_meta( $post_id, 'dish_subtitle', $meta_box_dish_subtitle );
		}

		return $post_id;
	}
}

add_filter( 'wp_mail_from_name', 'the_steam_get_blogname' );

add_action( 'wp_ajax_the_steam_submit_message', 'the_steam_submit_message' );
add_action( 'wp_ajax_nopriv_the_steam_submit_message', 'the_steam_submit_message' );
if ( ! function_exists( 'the_steam_submit_message' ) ) {
	/**
	 * Function used to send an e-mail with a message from a user of the website
	 */
	function the_steam_submit_message() {
		check_ajax_referer( 'the_steam_submit_message', 'security' );

		$ip = the_steam_get_sender_ip();

		if ( ! session_id() ) {
			session_start();
		}

		$curr_timestamp = $_SERVER['REQUEST_TIME'];

		/* Session expires in 30 minutes */
		$session_timeout = 30 * 60;

		/* Clean session on expiry. */
		if ( isset( $_SESSION['LAST_MSG_TIMESTAMP'] ) && (($curr_timestamp - $_SESSION['LAST_MSG_TIMESTAMP']) > $session_timeout) ) {
			session_unset();
			session_destroy();
			session_start();
			$_SESSION['CLIENT_IP'] = '';
			$_SESSION['LAST_MSG_TIMESTAMP'] = 0;
		}

		if ( 'yes' !== the_steam_get_option( 'option_disable_spam_limit' ) ) {
			if ( isset( $_SESSION['CLIENT_IP'] ) && $_SESSION['CLIENT_IP'] === $ip && array_key_exists( 'LAST_MSG_TIMESTAMP', $_SESSION ) &&
			     0 < absint( intval( $_SESSION['LAST_MSG_TIMESTAMP'] ) ) && ( $curr_timestamp - $_SESSION['LAST_MSG_TIMESTAMP'] ) < $session_timeout
			) {
				$err_msg = '<p id="user-message-response">' . esc_html__( 'Oops! Looks like you have already sent a message earlier! Please contact us by phone. Thank you!', 'thesteam' );
				$err_msg .= '</p>';

				die( wp_kses( $err_msg, the_steam_get_valid_theme_kses() ) );
			}
		}

		$_SESSION['LAST_MSG_TIMESTAMP'] = $curr_timestamp;
		$_SESSION['CLIENT_IP'] = $ip;

		$email = the_steam_sanitize_ajax_field( $_POST['email'], 'email' );
		$subject = the_steam_sanitize_ajax_field( $_POST['subject'], 'user_msg' );
		$message = 'New contact message from: ' . $email . ' : ';
		$message .= the_steam_sanitize_ajax_field( $_POST['message'], 'user_msg' );

		$headers = 'From: ' . esc_html( get_bloginfo( 'name' ) ) . ' <' . $email . ">\r\n";
		$headers .= 'Reply-To: ' . esc_html( get_bloginfo( 'name' ) ) . ' <' . $email . ">\r\n";
		$headers .= 'X-Mailer: PHP/' . phpversion() . "\r\n MIME-Version: 1.0 \r\n Content-type: text/html; charset=iso-8859-1\r\n BCC: ";

		if ( 'yes' !== the_steam_get_option( 'option_use_email_headers' ) ) {
			$headers = '';
		}

		$admin_email = the_steam_get_option( 'option_email_contact_us', get_option( 'admin_email' ), 500 );

		if ( ! isset( $admin_email ) || '' === $admin_email ) {
			die( esc_html__( 'We apologize, sending your message has failed...', 'thesteam' ) );
		}

		$confirmation = null;

		try {
			$res = wp_mail( $admin_email, $subject, $message, $headers );
			if ( false === $res ) {
				$confirmation = esc_html__( 'Unfortunately your message could not be sent. Please try again later or contact us by phone. Thank you!', 'thesteam' );
			} else {
				$confirmation = esc_html__( 'Thank you! We have received your message and will get back to you soon!', 'thesteam' );
			}
		} catch (Exception $e) {
			error_log( 'the_steam_submit_message(): '.$e->getMessage()."\n" );
			$confirmation = esc_html__( 'Unfortunately your message could not be sent. Please try again later or contact us by phone. Thank you!', 'thesteam' );
		}

		die( wp_kses( '<p id="user-message-response">'. $confirmation .'</p>', the_steam_get_valid_theme_kses() ) );
	}
} ?>
